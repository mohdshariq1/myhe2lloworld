/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.ignite.all.greatwest.object;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.all.greatwest.object.Organization;

/**
 * This example demonstrates use of binary objects with cache queries.
 * The example populates cache with sample data and runs several SQL and full text queries over this data.
 * <p>
 * Remote nodes should always be started with the following command:
 * {@code 'ignite.{sh|bat} examples/config/example-ignite.xml'}
 * <p>
 * Alternatively you can run {@link org.apache.ignite.examples.ExampleNodeStartup} in another JVM which will
 * start a node with {@code examples/config/example-ignite.xml} configuration.
 */
public class CacheOBJSimpleGetEngine {
    /** Organization cache name. */
    private static final String ORGANIZATION_CACHE_NAME = CacheOBJSimpleGetEngine.class.getSimpleName()
        + "Organizations";

    /** Employee cache name. */
    private static final String EMPLOYEE_CACHE_NAME = CacheOBJSimpleGetEngine.class.getSimpleName()
        + "Employees";

    /**
     * Executes example.
     *
     * @param args Command line arguments, none required.
     */
    public static void main(String[] args) {
        try (Ignite ignite = Ignition.start("examples/config/example-ignite.xml")) {
            System.out.println();
            System.out.println(">>> Binary objects cache query example started.");

            CacheConfiguration<Person, Organization> orgCacheCfg = new CacheConfiguration<>();

            orgCacheCfg.setCacheMode(CacheMode.PARTITIONED);
            orgCacheCfg.setName("CacheClientBinaryPutGetExample");//(ORGANIZATION_CACHE_NAME);

      

            try (IgniteCache<Person, Organization> orgCache = ignite.getOrCreateCache(orgCacheCfg);
                 
            ) {
                if (ignite.cluster().forDataNodes(orgCache.getName()).nodes().isEmpty()) {
                    System.out.println();
                    System.out.println(">>> This example requires remote cache nodes to be started.");
                    System.out.println(">>> Please start at least 1 remote cache node.");
                    System.out.println(">>> Refer to example's javadoc for details on configuration.");
                    System.out.println();

                    return;
                }
                do{
                	 int size = orgCache.size(null);
                     
                	try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                	
             //   	System.out.println("READING " +size+  "  cache value"+ orgCache.get(size));
                }
                while(true);

            }
        }
    }





}

