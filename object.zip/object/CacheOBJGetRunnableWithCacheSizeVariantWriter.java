package org.apache.ignite.all.greatwest.object;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteTransactions;
import org.apache.ignite.all.greatwest.util.StatisticsPerThread;
import org.apache.ignite.all.greatwest.object.Organization;
import org.apache.ignite.transactions.Transaction;

public class CacheOBJGetRunnableWithCacheSizeVariantWriter implements Runnable {

	private IgniteCache<Person, Organization> cache;
	private StatisticsPerThread statsThread;
	private Ignite ignite;
	private int startCacheIndex;
	private int endCacheIndex;

	public CacheOBJGetRunnableWithCacheSizeVariantWriter(
			IgniteCache<Person, Organization> orgCache) {
		// TODO Auto-generated constructor stub
		cache = orgCache;
	}

	public CacheOBJGetRunnableWithCacheSizeVariantWriter(
			IgniteCache<Person, Organization> orgCache, Ignite ignite,
			StatisticsPerThread statisticsPerThread, int startCacheIndex,
			int endCacheIndex) {
		this.cache = orgCache;
		this.statsThread = statisticsPerThread;
		this.ignite = ignite;
		this.startCacheIndex = startCacheIndex;
		this.endCacheIndex = endCacheIndex;
		// TODO Auto-generated constructor stub
	}

	public IgniteCache<Person, Organization> getCache() {
		return cache;
	}

	public void setCache(IgniteCache<Person, Organization> cache) {
		this.cache = cache;
	}

	public StatisticsPerThread getStatsThread() {
		return statsThread;
	}

	public int getStartCacheIndex() {
		return startCacheIndex;
	}

	public void setStartCacheIndex(int startCacheIndex) {
		this.startCacheIndex = startCacheIndex;
	}

	public int getEndCacheIndex() {
		return endCacheIndex;
	}

	public void setEndCacheIndex(int endCacheIndex) {
		this.endCacheIndex = endCacheIndex;
	}

	public void setStatsThread(StatisticsPerThread statsThread) {
		this.statsThread = statsThread;
	}

	@Override
	public void run() {
		long beforeThread = System.nanoTime();
		IgniteTransactions transactions = ignite.transactions();
		for (int i = 0; i < CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE.REPETITION_FOR_A_THREAD; i++) {
			int n = ThreadLocalRandom.current().nextInt(endCacheIndex);
			long beforeGetRun = System.nanoTime();
			// try (Transaction tx = transactions.txStart()) {
			Person p = new Person((long) n, (long) n, "FName" + n, "LName" + n);
			Organization org = cache.get(p);

			org.setName("Amazon" + n);
			cache.put(p, org);
			cache.get(p);
			// tx.commit();
			// }
			// System.out.println( Thread.currentThread()+ "--READING " +n+
			// "  cache value"+ cache.get(n));
			long afterGetRun = System.nanoTime();
			statsThread.setTotalNumberOfRunsByThread(statsThread
					.getTotalNumberOfRunsByThread() + 1);
			// System.out.println(statsThread.getTotalTimeByOneThread()+"NANO "
			// + (afterGetRun - beforeGetRun));
			statsThread.setTotalTimeByOneThread(statsThread
					.getTotalTimeByOneThread() + (afterGetRun - beforeGetRun));

		}
		// System.out.println("per thread tot run "
		// +statsThread.getTotalNumberOfRunsByThread());
		// System.out.println("per thread tot time "
		// +statsThread.getTotalTimeByOneThread());

	}

}
