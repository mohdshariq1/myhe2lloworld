/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.ignite.all.greatwest.object;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.examples.model.Address;
import org.apache.ignite.all.greatwest.object.Organization;
import org.apache.ignite.all.greatwest.object.Person;
import org.apache.ignite.examples.model.OrganizationType;

/**
 * This example demonstrates use of binary objects with Ignite cache.
 * Specifically it shows that binary objects are simple Java POJOs and do not require any special treatment.
 * <p>
 * The example executes several put-get operations on Ignite cache with binary values. Note that
 * it demonstrates how binary object can be retrieved in fully-deserialized form or in binary object
 * format using special cache projection.
 * <p>
 * Remote nodes should always be started with the following command:
 * {@code 'ignite.{sh|bat} examples/config/example-ignite.xml'}
 * <p>
 * Alternatively you can run {@link org.apache.ignite.examples.ExampleNodeStartup} in another JVM which will
 * start a node with {@code examples/config/example-ignite.xml} configuration.
 */
@SuppressWarnings("TypeMayBeWeakened")
public class CacheOBJSimplePutEngine {
    public static final int MAX_RANGEOF_KEYS = 5000;
	/** Cache name. */
    private static final String CACHE_NAME = CacheOBJSimplePutEngine.class.getSimpleName();

    /**
     * Executes example.
     *
     * @param args Command line arguments, none required.
     */
    public static void main(String[] args) {
        try (Ignite ignite = Ignition.start("examples/config/example-ignite.xml")) {
            System.out.println();
            System.out.println(">>> Binary objects cache put-get example started.");

            CacheConfiguration<Person, Organization> cfg = new CacheConfiguration<>();

            cfg.setCacheMode(CacheMode.REPLICATED);
            cfg.setName(CACHE_NAME);
            cfg.setAtomicityMode(CacheAtomicityMode.ATOMIC);

            try (IgniteCache<Person, Organization> cache = ignite.getOrCreateCache(cfg)) {
            	System.out.println("Start.." + cache.size(null));
            	if (ignite.cluster().forDataNodes(cache.getName()).nodes().isEmpty()) {
                    System.out.println();
                    System.out.println(">>> This example requires remote cache node nodes to be started.");
                    System.out.println(">>> Please start at least 1 remote cache node.");
                    System.out.println(">>> Refer to example's javadoc for details on configuration.");
                    System.out.println();

                    return;
                }
            	
                putGet(cache);
                System.out.println("End.." + cache.size(null));
            }
          /*  finally {
                // Delete cache with its content completely.
                ignite.destroyCache(CACHE_NAME);
            }*/
        }
    }

    /**
     * Execute individual put and get.
     *
     * @param cache Cache.
     */
    private static void putGet(IgniteCache<Person, Organization> cache) {
        // Create new Organization binary object to store in cache.
         int i=0;
        do{
        // Put created data entry to cache.
        	Person p = new Person((long)i, (long)i, "FName"+i, "LName"+i);	
			
        	 Organization org = new Organization(
        	            "Microsoft"+i, // Name.
        	            (long)i,new Address("1096 Eddy Street, San Francisco, CA", 94109), // Address.
        	            OrganizationType.PRIVATE, // Type.
        	            new Timestamp(System.currentTimeMillis())); // Last update time.
        	      
        	cache.put(p, org);

        // Get recently created organization as a strongly-typed fully de-serialized instance.
        Organization orgFromCache = cache.get(p);
       
        i=i+1;
        System.out.println();
        System.out.println(i +" Cache size=" + cache.size(null)+">>> Retrieved organization instance from cache: " + orgFromCache);
        }
        while(i<MAX_RANGEOF_KEYS);
    }

    public static void putGet(IgniteCache<Person, Organization> cache, int i, int range) {
        // Create new Organization binary object to store in cache.
         
        do{
        // Put created data entry to cache.
        	Person p = new Person((long)i, (long)i, "FName"+i, "LName"+i);	
			
        	 Organization org = new Organization(
        	            "Microsoft"+i, // Name.
        	            (long)i,new Address("1096 Eddy Street, San Francisco, CA", 94109), // Address.
        	            OrganizationType.PRIVATE, // Type.
        	            new Timestamp(System.currentTimeMillis())); // Last update time.
        	      
        	cache.put(p, org);

        // Get recently created organization as a strongly-typed fully de-serialized instance.
        Organization orgFromCache = cache.get(p);
       
        i=i+1;
     /*   System.out.println();
        System.out.println(i +" Cache size=" + cache.size(null)+">>> Retrieved organization instance from cache: " + orgFromCache);
     */   }
        while(i<range);
    }
   
}
