package org.apache.ignite.all.greatwest.object;

import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.ignite.Ignite;
import org.apache.ignite.all.greatwest.util.StatisticsPerThread;

public class CacheOBJGetRunnableForMAP implements Runnable {
	
	private Map<Person, Organization> cache;
	private StatisticsPerThread statsThread;
	
	

	public CacheOBJGetRunnableForMAP(Map<Person, Organization> orgCache,
			 StatisticsPerThread statisticsPerThread) {
		this.cache=orgCache;
		this.statsThread=statisticsPerThread;
		// TODO Auto-generated constructor stub
	}

	public Map<Person, Organization> getCache() {
		return cache;
	}

	public void setCache(Map<Person, Organization> cache) {
		this.cache = cache;
	}


	public StatisticsPerThread getStatsThread() {
		return statsThread;
	}

	public void setStatsThread(StatisticsPerThread statsThread) {
		this.statsThread = statsThread;
	}

	@Override
	public void run() {
		long beforeThread = System.nanoTime();
		for(int i=0;i<CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE.REPETITION_FOR_A_THREAD;i++){
			int n= ThreadLocalRandom.current().nextInt(CacheOBJConcurrentGetEngineMultipeRunsWithNODE.CACHE_SIZE);
				long beforeGetRun = System.nanoTime();
				Person p = new Person((long)n, (long)n, "FName"+n, "LName"+n);	
				Organization org = cache.get(p);
				/*org.setName("Amazon"+n);
				cache.put(p, org);
				cache.get(p);*/
				
		//	System.out.println( Thread.currentThread()+ "--READING " +n+  "  cache value"+ cache.get(n));
			long afterGetRun = System.nanoTime();
			statsThread.setTotalNumberOfRunsByThread(statsThread.getTotalNumberOfRunsByThread()+1);
		//	System.out.println(statsThread.getTotalTimeByOneThread()+"NANO " + (afterGetRun -  beforeGetRun));
			statsThread.setTotalTimeByOneThread( statsThread.getTotalTimeByOneThread()+ (afterGetRun -  beforeGetRun));
				
		}
	//	System.out.println("per thread tot run " +statsThread.getTotalNumberOfRunsByThread());
	//	System.out.println("per thread tot time " +statsThread.getTotalTimeByOneThread());
		
	}

}
