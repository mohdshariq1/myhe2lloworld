#include <iostream>

#include <bigmemory/x_platform.h>
#include <google/protobuf/wire_format_lite.h>
#include "recipe.pb.h"
#include "RecipeProtoBufSerializer.h"

void printRecipe(RecipeStructure structure, char const *string);

using terracotta::ehcache::XPlatform;
using terracotta::ehcache::Consistency;
using terracotta::ehcache::config::Configuration;
using terracotta::ehcache::exception::CacheException;
using terracotta::ehcache::search::SearchResult;

std::string readLine(const char *output) {
    std::cout << output;
    std::string input;
    std::getline(std::cin, input);
    return input;
}

int readInt32(const char *output) {
    std::string string = readLine(output);
    return atoi(string.c_str());
}

double readFloat(const char *output) {
    std::string string = readLine(output);
    return atof(string.c_str());
}

int selectOption() {
    std::cout << "Options: " << std::endl;
    std::cout << "1: Create a recipe" << std::endl;
    std::cout << "2: Look up a Recipe by name" << std::endl;
    std::cout << "3: Search for Recipe's" << std::endl;
    std::cout << "4: Exit" << std::endl;
    return readInt32("? ");
}

void parseMethod(RecipeProject::Method *method) {
    std::cout << "\tMethod:" << std::endl;
    std::cout << "\tWhen all method items are added enter 0 for method step" << std::endl;
    int step = 0;
    while ((step = readInt32("\t\tEnter Step number: ")) != 0) {
        RecipeProject::MethodItem *pItem = method->add_items();
        pItem->set_step_number(step);
        pItem->set_instruction(readLine("\t\tEnter step instruction: "));
    }
    std::cout << "\tDone with method" << std::endl;
}

void parseIngredients(RecipeProject::Ingredients *ingredients) {
    std::cout << "\tIngredients" << std::endl;
    std::cout << "\tWhen all ingredients are added enter 0 for quantity step" << std::endl;
    double qty = 0;
    while ((qty = readFloat("\t\tEnter Ingredient quantity as float: ")) != 0) {
        RecipeProject::Ingredient *pIngredient = ingredients->add_ingredient();
        pIngredient->set_quantity(qty);
        pIngredient->mutable_measurement()->set_measurement_type(readLine("\t\tMeasurement type: "));
        pIngredient->mutable_ingredient()->set_ingredient(readLine("\t\tDescription: "));
    }
    std::cout << "\tDone with ingredients" << std::endl;
}

void parseServing(RecipeProject::ServingInstructions *servingInstructions) {
    std::cout << "\tServings" << std::endl;
    servingInstructions->set_servings(readInt32("\t\tServings: "));
    RecipeProject::Measurement *measurement = new RecipeProject::Measurement();
    measurement->set_measurement_type(readLine("\t\tMeasurement type: "));
    servingInstructions->set_allocated_serving_measurement(measurement);
    parseMethod(servingInstructions->mutable_method());
}

int main(int argc, char **argv) {
    GOOGLE_PROTOBUF_VERIFY_VERSION;

    std::cout << "Welcome to the worlds fastest cook book!" << std::endl;
    std::string host = "localhost";
    int port = 8199;
    std::string cacheName = "TestCache";
    Consistency::Type type = Consistency::STRONG;
    if (argc > 1) host = argv[1];
    if (argc > 2) port = atoi(argv[2]);
    if (argc > 3) cacheName = argv[3];
    terracotta::ehcache::config::Configuration configuration = Configuration(host, port, 1);

    terracotta::ehcache::CacheManager *cacheManager = XPlatform::createCacheManager(configuration);
    RecipeProtoBufSerializer *serializer = new RecipeProtoBufSerializer();
    try {
        terracotta::ehcache::Cache<std::string, RecipeStructure> *cache = cacheManager->getCache(cacheName, *serializer);
        bool keepLooping = true;
        while (keepLooping) {
            switch (selectOption()) {
                case 1: {
                    std::cout << "Create a recipe " << std::endl;
                    RecipeStructure recipeStructure;
                    recipeStructure.set_name(readLine("Recipe Name: "));
                    recipeStructure.set_description(readLine("Recipe Description: "));
                    recipeStructure.set_preparation_time(readInt32("Preparation Time in minutes: "));
                    parseMethod(recipeStructure.mutable_method());
                    parseIngredients(recipeStructure.mutable_ingredients());
                    recipeStructure.set_baking_time(readInt32("Baking time in minutes: "));
                    parseServing(recipeStructure.mutable_instructions());
                    std::string key = recipeStructure.name();
                    cache->put(key, recipeStructure, type);
                }
                    break;
                case 2: {
                    std::cout << "Lookup by name" << std::endl;
                    std::string key = readLine("Key: ");
                    RecipeStructure structure = cache->get(key, type);
                    if (structure.IsInitialized()) {
                        printRecipe(structure, "\tResult for ");
                    } else {
                        std::cout << "\tNo such recipe!" << std::endl;
                    }
                    readLine("<Press enter to continue>");
                }
                    break;
                case 3: {
                    std::cout << "Search" << std::endl;
                    std::string queryString = readLine("Enter recipe name query: ");
                    terracotta::ehcache::SearchResults<std::string, RecipeStructure> *pResults = cache->query(queryString);
                    std::vector<terracotta::ehcache::SearchResult<std::string, RecipeStructure> *> *pVec = pResults->getResults();
                    std::vector<terracotta::ehcache::SearchResult<std::string, RecipeStructure> *>::iterator iter = pVec->begin();
                    std::vector<terracotta::ehcache::SearchResult<std::string, RecipeStructure> *>::iterator endIter = pVec->end();
                    std::cout << "Query returned " << pVec->size() << " results as follows:" << std::endl;
                    for (; iter != endIter; ++iter) {
                        SearchResult<std::string, RecipeStructure> *result = *iter;
                        printRecipe(result->getValue(), "\t - ");
                    }
                    delete (pResults);
                    readLine("<Press enter to continue>");
                }
                    break;
                default:
                    std::cout << "Bye!" << std::endl;
                    keepLooping = false;
            }
        }
    } catch (CacheException e) {
        switch (e.mCacheExceptionType) {
            case terracotta::ehcache::exception::CacheException::CACHE_NOT_FOUND:
                std::cout << "Sorry! No cache named '" << cacheName << "' exists on the server " << host << ":" << port << std::endl;
                break;
            default:
                std::cout << "Sorry! Something went horribly wrong! (" << e.mCacheExceptionType << ": " << e.what() << ")" << std::endl;
        }
    }

    delete cacheManager;
    google::protobuf::ShutdownProtobufLibrary();
    return 0;
}

void printRecipe(RecipeStructure structure, char const *string) {
    std::cout << string << structure.name() << ": " << structure.description() << " (" << structure.preparation_time() << " minutes to prepare)" << std::endl;
}

