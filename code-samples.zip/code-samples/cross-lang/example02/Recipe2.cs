﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

/*
 * Domain Recipe example for CLC C#. This file defines a collection of
 * classes to describe a "recipe", with prep time, bake time, ingredients,
 * prep methods, etc. 
 */
namespace Demo.Recipe2
{
    /*
     * Recipe2 class. Top level class, meant to represent a domain object
     * a user might use in a produnction system.
     */
    public class Recipe2
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
        
        [JsonProperty(PropertyName = "prepTime")]        
        public int PreperationTime { get; set; }
        
        [JsonProperty(PropertyName = "method")]
        public List<MethodItem> Method { get; set; }
        
        [JsonProperty(PropertyName = "ingredients")]
        public List<Ingredient> Ingredients { get; set; }
        
        [JsonProperty(PropertyName = "bakingTime")]
        public int BakingTime { get; set; } // optional

        [JsonProperty(PropertyName = "servingInstructions")]
        public ServingInstructions ServingInstructions { get; set; } // optional

        /*
         * This constructor is used for BSON auto deserialization.
         */
        public Recipe2() { }

        /*
         * Normal constructor. 
         */
        public Recipe2(string name, string desc, int
            prepTime, List<MethodItem> prepMethod, List<Ingredient> ingredients)
        {
            Name = name;
            Description = desc;
            PreperationTime = prepTime;
            Method = prepMethod;
            Ingredients = ingredients;
            BakingTime = -1;
            ServingInstructions = null;
        }

        public bool HasBakingTime()
        {
            return BakingTime > 0;
        }

        public bool HasServingInstructions()
        {
            return ServingInstructions != null;
        }

        public override string ToString()
        {
 	        StringWriter sw=new StringWriter();
            sw.WriteLine(Name);
            sw.WriteLine(Description);
            sw.WriteLine("Prep Time: "+PreperationTime);
            sw.WriteLine("Ingredients:");
            foreach (Ingredient ing in Ingredients)
            {
                sw.WriteLine("\t" + ing.ToString());
            }
            sw.WriteLine("Preperation:");
            foreach (MethodItem mi in Method) 
            {
                sw.WriteLine("\t" + mi.ToString());
            }

            if(BakingTime>0) 
            {
                sw.WriteLine("Baking Time: "+BakingTime);
            }
            if(HasServingInstructions()) 
            {
                sw.WriteLine(ServingInstructions.ToString());
            }
            return sw.ToString();
        }

    }

    /*
     * Single method for preparation.
     */
    public class MethodItem
    {
        [JsonProperty(PropertyName = "step")]
        public int Step { get; set; }

        [JsonProperty(PropertyName = "instruction")]
        public string Instruction { get; set; }

        public MethodItem() { }

        public MethodItem(int step, string instr)
        {
            Step = step;
            Instruction = instr;
        }

        public override string ToString()
        {
 	        return Step+". "+Instruction;
        }
    }

    /*
     * Single ingredient plus measurement.
     */
    public class Ingredient
    {
        [JsonProperty(PropertyName = "quantity")]
        public float Quantity { get; set; }
        
        [JsonProperty(PropertyName = "measurement")]
        public string Measurement { get; set; }

        [JsonProperty(PropertyName = "description")]
        public IngredientDescription Description { get; set; }

        public Ingredient() { }

        public Ingredient(float quant, string measurement, IngredientDescription descr)
        {
            Quantity = quant;
            Measurement = measurement;
            Description = descr;
        }

        public override string ToString()
        {
 	         return Quantity+" "+Measurement+" of "+Description;
        }

    }

    /*
     * Single ingredient plus an alternative.
     */
    public class IngredientDescription
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "alternative")]
        public string Alternative { get; set; }

        public IngredientDescription() { }

        public IngredientDescription(string name, string altname)
        {
            Name = name;
            Alternative = altname;
        }

        public IngredientDescription(string name)
            : this(name, null)
        {
        }

        public bool HasAlternative()
        {
            return Alternative != null;
        }

        public override string ToString()
        {
 	        string ret=Name;
            if(HasAlternative())
            {
                ret=ret+" ("+Alternative;
            }
            return ret;
        }
    }

    /*
     * Class describing serving instructions for the recipe. 
     */
    public class ServingInstructions
    {
        [JsonProperty(PropertyName = "servings")]
        public int Servings { get; set; }
        [JsonProperty(PropertyName = "measurement")]
        public string ServingMeasurement { get; set; }
        [JsonProperty(PropertyName = "method")]
        public List<MethodItem> Method { get; set; } // optional

        public ServingInstructions() { }

        public ServingInstructions(int servings, string servingMeasurement):this(servings,servingMeasurement,new List<MethodItem>())
        {
        }
     
        public ServingInstructions(int servings, string servingMeasurement,List<MethodItem> method)
        {
            Servings = servings;
            ServingMeasurement = servingMeasurement;
            Method = method;
        }

        public bool HasMethod()
        {
            return Method.Count>0;
        }

        public override string ToString()
        {
 	        StringWriter sw=new StringWriter();
            sw.WriteLine("Servings: "+Servings+" "+ServingMeasurement);
            foreach (MethodItem mi in Method) {
                sw.WriteLine(mi.ToString());
            }
            return sw.ToString();
        }
    }

    /*
     * Fluent builder for Recipe2 objects. 
     */
    public class Recipe2Builder
    {
        private string name;
        private string descr=null;
        private int ptime=-1;
        private int bakingTime = -1;
        private List<MethodItem> methods = new List<MethodItem>();
        private List<Ingredient> ingredients = new List<Ingredient>();
        private ServingInstructions servInstruction=null;

        public Recipe2Builder(string name)
        {
            this.name = name;
        }

        public Recipe2Builder description(string descr)
        {
            this.descr = descr;
            return this;
        }

        public Recipe2Builder preptime(int t)
        {
            this.ptime = t;
            return this;
        }

        public Recipe2Builder methodStep(string instruction)
        {
            methods.Add(new MethodItem(methods.Count + 1, instruction));
            return this;
        }

        public Recipe2Builder ingredient(float quant,string measurement,string name)
        {
            ingredients.Add(new Ingredient(quant, measurement, new IngredientDescription(name)));
            return this;
        }
        
        public Recipe2Builder ingredient(float quant,string measurement, string name,string altname)
        {
            ingredients.Add(new Ingredient(quant, measurement, new IngredientDescription(name,altname)));
            return this;
        }

        public Recipe2Builder baketime(int t)
        {
            this.bakingTime = t;
            return this;
        }

        public Recipe2Builder servingInstruction(int many,string measurement) {
            this.servInstruction = new ServingInstructions(many, measurement);
            return this;
        }

        public Recipe2Builder servingMethodStep(string instrs) {
            servInstruction.Method.Add(new MethodItem(servInstruction.Method.Count+1,instrs));
            return this;
        }

        public Recipe2 build()
        {
            Recipe2 br=new Recipe2(name,descr,ptime,methods,ingredients);
            if(this.bakingTime>0) 
            {
                br.BakingTime=this.bakingTime;
            }
            if(this.servInstruction!=null) 
            {
                br.ServingInstructions=this.servInstruction;
            }
            return br;
        }

    }
}
