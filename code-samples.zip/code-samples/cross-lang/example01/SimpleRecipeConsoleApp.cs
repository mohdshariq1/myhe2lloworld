﻿using System;
using Newtonsoft.Json;
using Terracotta.Ehcache;
using Terracotta.Ehcache.Caching;
using Terracotta.Ehcache.Config;
using Terracotta.Ehcache.Search;

namespace RecipeProject
{
    class SimpleRecipeConsoleApp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the worlds fastest cook book!");
            ICacheManager cacheManager = XPlatform.CreateCacheManager(new Terracotta.Ehcache.Config.Configuration("localhost", 8199, 100));
            ICache<String, RecipeProject.RecipeStructure> cache = cacheManager.GetCache("TestCache", new RecipeSerializer());

            bool keepLooping = true;
            while (keepLooping)
            {
                switch (selectOption())
                {
                    case 1:
                        {
                            RecipeProject.RecipeStructure recipe = new RecipeProject.RecipeStructure();
                            recipe.name = readLine("Recipe Name: ");
                            recipe.description = readLine("Recipe Description: ");
                            recipe.preparation_time = Convert.ToInt32(readLine("Preparation Time in minutes: "));
                            Console.WriteLine("\t\tMethod");
                            recipe.method = readMethod();
                            Console.WriteLine("\t\tMethod Completed");
                            recipe.ingredients = readIngredientList();
                            recipe.baking_time = Convert.ToInt32(readLine("Baking TIme in minutes: "));
                            recipe.instructions = readServingInstructions();
                            cache.Put(recipe.name, recipe, ConsistencyType.STRONG);
                            break;
                        }
                    case 2:
                        {
                            RecipeProject.RecipeStructure recipe = cache.Get(readLine("Enter recipe name: "), ConsistencyType.STRONG);
                            if (recipe != null)
                            {
                                displayRecipe(recipe);
                            }
                            else
                            {
                                Console.WriteLine("No known recipe");
                            }
                            break;
                        }
                    case 3:
                        {
                            SearchResults<String, RecipeProject.RecipeStructure> query = cache.Query(readLine("Enter recipe name query: "));
                            Console.WriteLine("Query returned " + query.Results.Count + " results as follows");
                            foreach (SearchResult<String, RecipeProject.RecipeStructure> result in query.Results)
                            {
                                displayRecipe(result.Value);
                            }
                            break;
                        }
                    default:
                        {
                            keepLooping = false;
                            break;
                        }
                }
            }

            cacheManager.Close();
        }

        private static void displayRecipe(RecipeProject.RecipeStructure recipe)
        {
            Console.WriteLine(JsonConvert.SerializeObject(recipe));
        }

        private static RecipeProject.ServingInstructions readServingInstructions()
        {
            RecipeProject.ServingInstructions instructions = new RecipeProject.ServingInstructions();
            Console.WriteLine("\t\tServing Instructions ");
            instructions.servings = Convert.ToInt32(readLine("Servings as int: "));
            instructions.serving_measurement = readMeasurement();
            Console.WriteLine("");
            instructions.method = readMethod();
            Console.WriteLine("\t\tServing Instructions Completed");
            return instructions;
        }

        private static RecipeProject.Ingredients readIngredientList()
        {
            Console.WriteLine("\t\tIngredients");
            Console.WriteLine("When all ingredients are added enter 0 for quantity step");
            RecipeProject.Ingredients ingredients = new RecipeProject.Ingredients();
            while (true)
            {
                float quantity = Convert.ToSingle(readLine("Enter Ingredient quantity as float: "));
                if (quantity == 0)
                {
                    Console.WriteLine("\t\tIngredients Completed");
                    return ingredients;
                }
                ingredients.ingredient.Add(readIngredient(quantity));
            }

        }

        private static RecipeProject.Ingredient readIngredient(float stepNumber)
        {
            RecipeProject.Ingredient item = new RecipeProject.Ingredient();
            item.quantity = stepNumber;
            item.measurement = readMeasurement();
            item.ingredient = readIngredientDescription();
            return item;
        }

        private static RecipeProject.IngredientDescription readIngredientDescription()
        {
            RecipeProject.IngredientDescription ingredient = new RecipeProject.IngredientDescription();
            ingredient.ingredient = readLine("Enter Ingredient Description: ");
            if (Convert.ToInt32(readLine("To add an alternative ingredient enter 1 else 0: ")) == 1)
            {
                float quantity = Convert.ToSingle(readLine("Enter Ingredient quantity as float: "));
                ingredient.alternative_ingredient = readIngredient(quantity);
            }
            return ingredient;
        }

        private static RecipeProject.Measurement readMeasurement()
        {
            RecipeProject.Measurement measurement = new RecipeProject.Measurement();
            measurement.measurement_type = readLine("\tEnter measurement type: ");
            return measurement;
        }

        private static RecipeProject.Method readMethod()
        {
            Console.WriteLine("When all method items are added enter 0 for method step");
            RecipeProject.Method method = new RecipeProject.Method();
            while (true)
            {
                int stepNumber = Convert.ToInt32(readLine("Enter Step number: "));
                if (stepNumber == 0)
                {
                    return method;
                }
                RecipeProject.MethodItem item = new RecipeProject.MethodItem();
                item.step_number = stepNumber;
                item.instruction = readLine("Enter step instruction: ");
                method.items.Add(item);
            }
        }

        private static int selectOption()
        {
            Console.WriteLine("Options:");
            Console.WriteLine("1: Create a recipe");
            Console.WriteLine("2: Look up a Recipe by name");
            Console.WriteLine("3: Search for Recipe's");
            Console.WriteLine("4: Exit");
            return Convert.ToInt32(readLine("Please Select Options:"));
        }

        private static string readLine(string message)
        {
            Console.WriteLine(message);
            return Console.ReadLine();
        }
    }
}
