/*
 * All content copyright Terracotta, Inc., unless otherwise indicated. All rights reserved.
*/

package com.bigmemory.samples.wan;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.TerracottaClientConfiguration;
import net.sf.ehcache.config.TerracottaConfiguration;
import org.apache.commons.lang.StringUtils;

import java.util.Scanner;

import static com.google.common.base.Preconditions.checkState;

public class WanReplication {

  private static final String CMD_PROMPT = " > ";
  private static final String UNKNOWN_CMD_MSG = "Unknown command. One of [connect|disconnect|put|get|size|fill|contend|remove|help|exit] expected";
  private static final String CLIENT_NOT_CONNECTED_MSG = "The client must be connected to the server to run this command";
  private static final String NOT_ENOUGH_ARGUMENTS_MSG = "Not enough arguments";

  private static CacheManager cacheManager;
  private static Ehcache cache;
  private static String connectedTsa = "";

  public static void main(String[] args) {
    final Scanner inputScanner = new Scanner(System.in);

    while (true) {
      System.out.print(connectedTsa + CMD_PROMPT);
      final String expr = inputScanner.nextLine();
      if (StringUtils.isBlank(expr)) {
        continue;
      }

      final Scanner cmdScanner = new Scanner(expr);
      final String body = cmdScanner.next();
      final Command cmd;
      try {
        cmd = Command.valueOf(body.trim().toUpperCase());
      } catch (IllegalArgumentException e) {
        System.out.println(UNKNOWN_CMD_MSG);
        cmdScanner.close();
        continue;
      }

      try {
        cmd.run(cmdScanner);
      } catch (IllegalArgumentException e) {
        System.out.println(e.getMessage());
        System.out.println(cmd.usage());
      } catch (IllegalStateException e) {
        System.out.println(e.getMessage());
        System.out.println(cmd.usage());
      } catch (Exception e) {
        System.out.println(cmd.usage());
        System.out.print("Unexpected error occurred: ");
        e.printStackTrace();
      } finally {
        cmdScanner.close();
      }
    }
  }

  private enum Command {

    EXIT {
      @Override
      void run(final Scanner scanner) {
        System.out.println("Exiting...");
        if (cache != null) { cache.dispose(); }
        if (cacheManager != null) { cacheManager.shutdown(); }
        System.exit(0);
      }
    },

    CONNECT {
      @Override
      void run(final Scanner scanner) {
        checkState(cache == null, "The client is already connected to a cache, use 'disconnect' command first");
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);
        final String url = scanner.next();
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);
        final String cacheName = scanner.next();

        //TODO: get from ehcache.xml
        final CacheConfiguration cacheConfig = new CacheConfiguration()
            .name(cacheName)
            .maxEntriesLocalHeap(10000)
            .terracotta(new TerracottaConfiguration().clustered(true));

        final Configuration cacheManagerConfig = new Configuration()
            .name(CacheManager.DEFAULT_NAME)
            .terracotta(new TerracottaClientConfiguration().url(url).rejoin(true).wanEnabledTSA(true))
            .cache(cacheConfig);

        cacheManager = CacheManager.create(cacheManagerConfig);
        cache = cacheManager.getEhcache(cacheName);
        System.out.println("Successfully connected to '" + cache.getName() + "'");
        connectedTsa = url;
      }

      @Override
      String usage() {
        return super.usage() + " <toolkit_url> <cache_name>";
      }
    },

    DISCONNECT {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);

        cache.dispose();
        cacheManager.shutdown();
        cache = null;
        cacheManager = null;
        connectedTsa = "";
      }
    },

    HELP {
      @Override
      void run(final Scanner scanner) {
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);

        try {
          final String cmdName = scanner.next();
          final Command cmd = Command.valueOf(cmdName.trim().toUpperCase());
          System.out.println(cmd.usage());
        } catch (IllegalArgumentException e) {
          System.out.println(usage());
        }
      }

      @Override
      String usage() {
        return super.usage() + " <other_command>";
      }
    },

    PUT {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);

        final String key = scanner.next();
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);
        final String value = scanner.next();

        cache.put(new Element(key, value));
      }

      @Override
      String usage() {
        return super.usage() + " <key> <value>";
      }
    },

    FILL {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);

        final int count = Integer.parseInt(scanner.next());
        checkState(count > 0, "The number of elements to insert should be a positive integer");

        for (int i = 0; i < count; i++) {
          cache.put(new Element("k" + i, "v" + i));
        }
      }

      @Override
      String usage() {
        return super.usage() + " <number of elements to generate>";
      }
    },

    CONTEND {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);
        final String key = scanner.next();
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);
        final int count = Integer.parseInt(scanner.next());
        checkState(count > 0, "The number of updates per key should be a positive integer");

        for (int i = 0; i < count; i++) {
          cache.put(new Element(key, "v" + i));
        }
      }

      @Override
      String usage() {
        return super.usage() + "<key> <number of updates per key>";
      }
    },

    GET {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);

        final String key = scanner.next();
        final Element element = cache.get(key);
        if (element == null) {
          System.out.println("Not found");
        } else {
          System.out.println("[" + element.getObjectKey()
                             + ", " + element.getObjectValue() + "]");
        }
      }

      @Override
      String usage() {
        return super.usage() + " <key>";
      }
    },

    SIZE {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        System.out.println("[" + cache.getSize() + "]");
      }
    },

    REMOVE {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        checkState(scanner.hasNext(), NOT_ENOUGH_ARGUMENTS_MSG);

        final String key = scanner.next();
        cache.remove(key);
      }

      @Override
      String usage() {
        return super.usage() + " <key>";
      }
    },

    CLEAR {
      @Override
      void run(final Scanner scanner) {
        checkState(cache != null, CLIENT_NOT_CONNECTED_MSG);
        cache.removeAll();
      }
    };

    abstract void run(final Scanner scanner);

    String usage() {
      return "Usage: " + this.name().toLowerCase();
    }
  }

}
