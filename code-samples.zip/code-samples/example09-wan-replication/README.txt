Using BigMemory WAN replication
==========

Overview:
=========
This is an application to demonstrate the Wide Area Network (WAN) Replication service for Big Memory Max clusters.
WAN replication enables two or more BigMemory Max clusters to share data in an eventually consistent manner.
More information can be found at http://www.terracotta.org/kit/reflector?kitID=default&pageID=BMMCodeSamples.

The scenario simulated here involves two BigMemory Max clusters, named region-1 and region-2.
Any data stored in region-1 will be shown to be replicated to region-2, and vice versa.

Requirements:
===============
Be sure to have the JAVA_HOME defined.
For Windows users, you can use the following command:
set JAVA_HOME="path/to/java/home"
For UNIX/Linux users, you can use the following command:
export JAVA_HOME="path/to/java/home"

Running the Example:
====================

1. Modify wan-config-region-1.xml and wan-config-region-2.xml files and replace the "wan-samples-root-dir" placeholder
with the actual location of the folder.

2. Launch region-1 TSA with the start-sample-server-1.sh.

3. Launch region-2 TSA with the start-sample-server-2.sh.

4. Launch region-1 WAN Orchestrator with the start-orch-1.sh.

5. Launch region-2 WAN Orchestrator with the start-orch-2.sh.

Note: on Windows machines use corresponding *.bat scripts instead of *.sh.

Now that TSA and WAN services for regions 1 and 2 have started, we are ready to run the application and demonstrate the replication process.

6. Start Region-1 Application with run.sh. You should see a command prompt which indicates that the application
has started and is ready to accept various instructions.

7. Next, at the command prompt type:

    > connect localhost:9510 bar

This will start the application's cache manager and make region-1 cluster operational.

8. Start Region-2 Application by repeating step 4, but at the command prompt, type:

    > connect localhost:9610 bar

9. Store some elements into region-1 TSA by typing the following on region-1 application:

    > fill 100

This command will put 100 keys named k0, k1, ... k99 with values v0, v1, ... , v99 into region-1.

10. See if the element's have been replicated to region-2 TSA by typing the following on region-2 application:

    > get k0

You should see [k0, v0] as the result which indicates that the key k0 which was inserted on region-1 was successfully replicated to region-2.

11. Change the k0 value from region-2 by doing the following:

    > put k0 baz

This "put" which happened on region-2 should now be visible in region-1. Type the following on the command prompt of region-1:

    > get k0

You should see [k0, baz] as the result which indicates successful replication.

Termination and Clean Up:
====================
Use stop-*.sh scripts or kill all the java processes by sending a ctrl-c signal.

More info:
====================
Also read the README.txt in the code-samples directory.








