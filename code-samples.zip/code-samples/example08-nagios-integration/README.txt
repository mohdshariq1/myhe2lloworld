This script is an example of a Nagios plugin to check if a Node left event occured.
A Node left event occurs when a node is leaving the Terracotta cluster
http://www.terracotta.org/kit/reflector?kitID=default&pageID=BMMCodeSamples
This plugin has three parameters: 

$SERVER $PORT $INTERVAL

$SERVER : Terracotta server
$PORT : Terracotta server port (e.g. 9530)
$INTERVAL : amount of time in minutes in the past to which the check applies. (e.g. 10 will check in the last 10 minutes)

To see how to install this plugin, you should refer to the tutorial:
http://www.youtube.com/watch?v=jG1lVnire4E

