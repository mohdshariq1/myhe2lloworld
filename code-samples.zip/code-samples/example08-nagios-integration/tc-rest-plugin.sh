#!/bin/bash

SERVER=$1
PORT=$2
INTERVAL=$3


RESTURL="http://${SERVER}:${PORT}/tc-management-api/agents/operatorEvents?sinceWhen=${INTERVAL}m"

GET_INFO=`curl "$RESTURL" -s | grep left`
NB_LINES=`echo $GET_INFO | wc -l`
if [[ $NB_LINES -gt 0 ]]; then
       SERVER_LIST=''
       for i in `echo $GET_INFO | sed 's/.*Node\(.*\)left the cluster.*/\1/g'`; do SERVER_LIST="$SERVER_LIST $i"; done
       echo $SERVER_LIST 
       CHECK="NODE_LEFT"
else
       CHECK="NO_EVENT"
fi

if [[ "$CHECK" == "NODE_LEFT" ]]; then
   echo "NODE LEFT EVENT: $SERVER_LIST"
   exit 2
elif [[ "$CHECK" == "NO_EVENT" ]]; then
   echo "No NODE LEFT Event: ${SERVER}"
   exit 0
else
   echo "Check failed"
   exit 3
fi


