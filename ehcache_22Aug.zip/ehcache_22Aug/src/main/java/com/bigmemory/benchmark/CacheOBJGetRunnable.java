package com.bigmemory.benchmark;

import java.util.concurrent.ThreadLocalRandom;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.TransactionController;

import com.bigmemory.benchmark.util.StatisticsPerThread;

public class CacheOBJGetRunnable implements Runnable {
	
	private Cache  bigMemory;
	private CacheManager manager;
	public CacheManager getManager() {
		return manager;
	}



	public void setManager(CacheManager manager) {
		this.manager = manager;
	}



	public Cache getBigMemory() {
		return bigMemory;
	}



	public void setBigMemory(Cache bigMemory) {
		this.bigMemory = bigMemory;
	}

	private StatisticsPerThread statsThread;
	

	public CacheOBJGetRunnable(Cache bigMemory, CacheManager manager,
			 StatisticsPerThread statisticsPerThread) {
		this.bigMemory= bigMemory;
		this.manager=manager;
		this.statsThread=statisticsPerThread;
		// TODO Auto-generated constructor stub
	}



	public StatisticsPerThread getStatsThread() {
		return statsThread;
	}

	public void setStatsThread(StatisticsPerThread statsThread) {
		this.statsThread = statsThread;
	}

	
	public void run() {
		long beforeThread = System.nanoTime();
		for(int i=0;i<CacheOBJConcurrentGetEngineMultipeRunsWithTHREADSIZE.REPETITION_FOR_A_THREAD;i++){
			int n= ThreadLocalRandom.current().nextInt(CacheOBJConcurrentGetEngineMultipeRunsWithTHREADSIZE.CACHE_SIZE);
				long beforeGetRun = System.nanoTime();
				
			    TransactionController txCtrl = manager.getTransactionController();
	    	    
	    	    txCtrl.begin();
	   
				
				Person p = new Person((long) n, (long) n, "Shariq-" + n, "Mohd" +n);
			 	
				Element e= bigMemory.get(p);
	    		//System.out.println("READ*** The new value*** "+  e.getObjectValue().toString());
				Organization org = (Organization)(e.getObjectValue());
				org.setName("Amazon"+n);
		/*		bigMemory.put(new Element(p, org));
				bigMemory.get(p);*/
			    txCtrl.commit();
		
			
				
		//	System.out.println( Thread.currentThread()+ "--READING " +n+  "  cache value"+ cache.get(n));
			long afterGetRun = System.nanoTime();
			statsThread.setTotalNumberOfRunsByThread(statsThread.getTotalNumberOfRunsByThread()+1);
		//	System.out.println(statsThread.getTotalTimeByOneThread()+"NANO " + (afterGetRun -  beforeGetRun));
			statsThread.setTotalTimeByOneThread( statsThread.getTotalTimeByOneThread()+ (afterGetRun -  beforeGetRun));
				
		}
	//	System.out.println("per thread tot run " +statsThread.getTotalNumberOfRunsByThread());
	//	System.out.println("per thread tot time " +statsThread.getTotalTimeByOneThread());
		
	}



}
