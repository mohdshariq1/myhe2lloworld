package com.bigmemory.benchmark.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class RunTCnodes {
	public static void main(String[] args) throws IOException,
			InterruptedException {

		ProcessBuilder pb = new ProcessBuilder(
				"G:\\workspace\\bigmemory-max-4.3.2.1.7\\code-samples\\example03-crud\\start-sample-server.bat");
		pb.redirectErrorStream(true);
		Process p = pb.start();
		InputStream is = p.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		for (String line = br.readLine(); line != null; line = br.readLine()) {
			System.out.println(">" + line); // Or whatever processing you may
											// want to do
		}
		p.waitFor();

	}

	public static void runNode(String fileName, int count) {
		try {
			ProcessBuilder pb = new ProcessBuilder(fileName + count + ".bat");
			pb.redirectErrorStream(true);
			Process p;

			p = pb.start();

			InputStream is = p.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			for (String line = br.readLine(); line != null; line = br
					.readLine()) {
				System.out.println(">" + line); // Or whatever processing you
												// may want to do
			}
			p.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
