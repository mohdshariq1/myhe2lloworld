package com.bigmemory.benchmark;

import java.util.concurrent.ThreadLocalRandom;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import com.bigmemory.benchmark.util.StatisticsPerThread;

public class CacheOBJGetRunnable implements Runnable {
	
	private Cache  bigMemory;
	public Cache getBigMemory() {
		return bigMemory;
	}



	public void setBigMemory(Cache bigMemory) {
		this.bigMemory = bigMemory;
	}

	private StatisticsPerThread statsThread;
	

	public CacheOBJGetRunnable(Cache bigMemory,
			 StatisticsPerThread statisticsPerThread) {
		this.bigMemory= bigMemory;
		this.statsThread=statisticsPerThread;
		// TODO Auto-generated constructor stub
	}



	public StatisticsPerThread getStatsThread() {
		return statsThread;
	}

	public void setStatsThread(StatisticsPerThread statsThread) {
		this.statsThread = statsThread;
	}

	
	public void run() {
		long beforeThread = System.nanoTime();
		for(int i=0;i<CacheOBJConcurrentGetEngineMultipeRunsWithTHREADSIZE.REPETITION_FOR_A_THREAD;i++){
			int n= ThreadLocalRandom.current().nextInt(CacheOBJConcurrentGetEngineMultipeRunsWithTHREADSIZE.CACHE_SIZE);
				long beforeGetRun = System.nanoTime();
				Person p = new Person((long) n, (long) n, "Shariq-" + n, "Mohd" +n);
			 	
				Element e= bigMemory.get(p);
				e.getObjectValue();
				/*org.setName("Amazon"+n);
				cache.put(p, org);
				cache.get(p);*/
			
				
		//	System.out.println( Thread.currentThread()+ "--READING " +n+  "  cache value"+ cache.get(n));
			long afterGetRun = System.nanoTime();
			statsThread.setTotalNumberOfRunsByThread(statsThread.getTotalNumberOfRunsByThread()+1);
		//	System.out.println(statsThread.getTotalTimeByOneThread()+"NANO " + (afterGetRun -  beforeGetRun));
			statsThread.setTotalTimeByOneThread( statsThread.getTotalTimeByOneThread()+ (afterGetRun -  beforeGetRun));
				
		}
	//	System.out.println("per thread tot run " +statsThread.getTotalNumberOfRunsByThread());
	//	System.out.println("per thread tot time " +statsThread.getTotalTimeByOneThread());
		
	}



}
