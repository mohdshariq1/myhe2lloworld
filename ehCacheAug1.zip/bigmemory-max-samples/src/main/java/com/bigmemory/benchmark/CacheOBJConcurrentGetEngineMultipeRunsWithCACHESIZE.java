/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.bigmemory.benchmark;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.MemoryUnit;
import net.sf.ehcache.config.TerracottaClientConfiguration;
import net.sf.ehcache.config.TerracottaConfiguration;

import org.jfree.data.category.DefaultCategoryDataset;

import com.bigmemory.benchmark.util.JfreeChart;
import com.bigmemory.benchmark.util.LineChart;
import com.bigmemory.benchmark.util.StatisticsPerRun;
import com.bigmemory.benchmark.util.StatisticsPerSet;
import com.bigmemory.benchmark.util.StatisticsPerThread;

/**
 * This example demonstrates use of binary objects with cache queries.
 * The example populates cache with sample data and runs several SQL and full text queries over this data.
 * <p>
 * Remote nodes should always be started with the following command:
 * {@code 'ignite.{sh|bat} examples/config/example-ignite.xml'}
 * <p>
 * Alternatively you can run {@link org.apache.ignite.examples.ExampleNodeStartup} in another JVM which will
 * start a node with {@code examples/config/example-ignite.xml} configuration.
 */
public class CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE {
    private static final int CACHE_INCREMENT = 1000;

	private static final int THREAD_POOL_INCREMENT = 3;

	private static final int THREAD_POOL_MAX_SIZE = 40;

	public static final long NUMBER_OF_RUNS_TEST = 4;

    public static final int REPETITION_FOR_A_THREAD = 200;

	public static final String CACHE_NAME = "CacheOBJSimplePutEngine";

	public static final long TOTAL_THREADS_FOR_CONCURRENT_READ = 20;

	public static  final long THREAD_POOLSIZE_FOR_CONCURRENT_READ=10 ; // This varies

	public static final int CACHE_SIZE = 10000;

    /**
     * Executes example.
     *
     * @param args Command line arguments, none required.
     * @throws InterruptedException 
     */
    public static void main(String[] args) throws InterruptedException {
        
	            //Setting up a Cache
    	 Configuration managerConfiguration = new Configuration();
    	    managerConfiguration.name("config")
    	        .terracotta(new TerracottaClientConfiguration().url("localhost:9510"))
    	        .cache(new CacheConfiguration()
    	            .name("bigMemory-crud")
    	            .maxBytesLocalHeap(128, MemoryUnit.MEGABYTES)
    	            .terracotta(new TerracottaConfiguration())
    	        );

    	    CacheManager manager = CacheManager.create(managerConfiguration);
    	    Cache bigMemory = manager.getCache("bigMemory-crud");

    	    
        		DefaultCategoryDataset finalStats = new DefaultCategoryDataset();
        	

        		//Populating the Cache
        		
                for(int indexCache=1;indexCache<=CACHE_SIZE;indexCache=indexCache+CACHE_INCREMENT){
                	
                	CacheOBJSimplePutEngine.put(bigMemory, indexCache, CACHE_INCREMENT);
            		
                	StatisticsPerSet statSet=new StatisticsPerSet();
                	executePerSetOfThreads(bigMemory, statSet);
                	
                	finalStats.setValue(statSet.getOpsPerSec(),
    						" Concurrent Ops Per Sec ",
    						(Long) ((long)indexCache ));
    					
                	System.out.println("FINAL LOOP INDEX " + indexCache+ " GOING TO MAXLIMIT " + THREAD_POOL_MAX_SIZE);
                }
                
                
            JfreeChart.graph(finalStats, "  OneGetPutGetTX AverageTime ", "Average Time in Nanoseconds", "Test Run Index", "Average Time taken by One Operation");
            LineChart.graph(finalStats, "FINAL Operations per second per Threads Pool Size", "  OneGetPutGetTX OpsPerSec ", "Number of Operations Per Second Per Threads Pool", "Thread Pool Size");

        
    }

	private static void executePerSetOfThreads(Cache bigMemory, StatisticsPerSet stasSet)
			throws InterruptedException {
		List<StatisticsPerRun> statsList = new ArrayList<StatisticsPerRun>();	
            long befTime=System.nanoTime();
		for(int i=0;i<NUMBER_OF_RUNS_TEST;i++){
			StatisticsPerRun stats = new StatisticsPerRun();
			executeGetCache( bigMemory, stats);
			statsList.add(stats);
		}
		long aftTime=System.nanoTime();
		
		System.out.println("Total Time " +(aftTime-befTime));

		System.out.println("Total Ops Per Sec " + (double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime));
		
		
		DefaultCategoryDataset dataSetOpsPerSec = new DefaultCategoryDataset();
		DefaultCategoryDataset dataSetAvgTimeForOneOp = new DefaultCategoryDataset();
		DefaultCategoryDataset dataSetConcurrentOpsPerSec = new DefaultCategoryDataset();
		int i=0;long baseTime=0;
		double AVG_TIME_SET=0;
		double OPS_PER_SEC_SET =0;
		
		for(StatisticsPerRun statPerSet : statsList){
			AVG_TIME_SET = (long) (statPerSet.getAverageTimeforOneGet()+AVG_TIME_SET);
			OPS_PER_SEC_SET=OPS_PER_SEC_SET+ statPerSet.getConcurrentOperationsPerSec();
		
			
			//		if (i > 1) {// since couple of test take time to warmup
				if (i == 0) {
					baseTime = (Long) statPerSet.getCurrentTime();
				}

				// System.out.println(statPerSet.getOpsPerSec() +" ----"
				// + (Long)(statPerSet.getCurrentTime() - baseTime));
				dataSetOpsPerSec.setValue(statPerSet.getOpsPerSec(),
						" Ops Per Sec ",
						(Long) (statPerSet.getCurrentTime() - baseTime));
				
				dataSetConcurrentOpsPerSec.setValue(statPerSet.getConcurrentOperationsPerSec(),
						" Concurrent Ops Per Sec ",
						(Long) (statPerSet.getCurrentTime() - baseTime));
				dataSetAvgTimeForOneOp.setValue(statPerSet.getAverageTimeforOneGet(),
						" Avg Time ",
						(Long) (statPerSet.getCurrentTime() - baseTime));
		//	}
			i++;
		}
		
		System.out.println("OuterMOST Total Time for One SET-(aftTime-befTime)= " +(aftTime-befTime));
		System.out.println("OuterMOST OLDER   Total Ops One SET Per Sec " + (double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime));
		
			stasSet.setCurrentTime(System.currentTimeMillis());
			stasSet.setOpsPerSec(OPS_PER_SEC_SET/NUMBER_OF_RUNS_TEST);
			stasSet.setAverageTimeforOneGet(AVG_TIME_SET/NUMBER_OF_RUNS_TEST);
			System.out.println("OUTER LOOP -->OPS/SEC=" + stasSet.getOpsPerSec() +" AVERGE  "+ stasSet.getAverageTimeforOneGet());
			System.out.println("OUTER LOOP -->OPS_PER_SEC_SET " + OPS_PER_SEC_SET + "NUMBER_OF_RUNS_TEST "+NUMBER_OF_RUNS_TEST +" AVG_TIME_SET "+ AVG_TIME_SET);
				
		
		
		
            JfreeChart.graph(dataSetOpsPerSec, "  OneGetPutGetTX OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Operations Per Second", "Test Run Index", "Operations per second");
            JfreeChart.graph(dataSetConcurrentOpsPerSec, "  OneGetPutGetTX - ALL OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Concurrent Operations Per Second", "Test Run Index", "Concurrent Operations per second");
            JfreeChart.graph(dataSetAvgTimeForOneOp, "  OneGetPutGetTX AverageTime " +   (int)((double)(aftTime-befTime)/(int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD )) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf", "Average Time in Nanoseconds", "Test Run Index", "Average Time taken by One Operation");


            
            LineChart.graph(dataSetOpsPerSec, "Operations per second", "  OneGetPutGetTX OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Operations Per Second", "Test Run Index");
            LineChart.graph(dataSetConcurrentOpsPerSec,"Concurrent Operations per second", "  OneGetPutGetTX - ALL OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Concurrent Operations Per Second", "Test Run Index" );
            LineChart.graph(dataSetAvgTimeForOneOp,"Average Time For One Operation", "  OneGetPutGetTX AverageTime " +   (int)((double)(aftTime-befTime)/(int)((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD )) ) +"  Threads- "+TOTAL_THREADS_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf", "Average Time in Nanoseconds", "Test Run Index");
	}

	private static void executeGetCache(
			Cache bigMemory, StatisticsPerRun stats)
			throws InterruptedException {
		List<StatisticsPerThread> listOfStatsForThread = new ArrayList<StatisticsPerThread>(50000);
		
		ExecutorService executor = Executors.newFixedThreadPool((int)THREAD_POOLSIZE_FOR_CONCURRENT_READ);
            //	List<Statistics> listOfStats = new ArrayList<Statistics>(50000);
		long befConTime=System.nanoTime();
		for (int i = 0; i < TOTAL_THREADS_FOR_CONCURRENT_READ; i++) {
				listOfStatsForThread.add(i, new StatisticsPerThread());
		        Runnable worker = new CacheOBJGetRunnable( bigMemory , listOfStatsForThread.get(i));
		        executor.execute(worker);
		        //TheUtils.timeLapse(2);
		}
		// This will make the executor accept no new threads
		// and finish all existing threads in the queue
		executor.shutdown();
		// Wait until all threads are finish
		executor.awaitTermination(1,TimeUnit.HOURS);
		long aftConTime=System.nanoTime();
		System.out.println("TOT="+ TOTAL_THREADS_FOR_CONCURRENT_READ*REPETITION_FOR_A_THREAD);
		System.out.println("TOT time="+ (aftConTime-befConTime));
		System.out.println("TOT CONCURRENT ops per sec="+ (double)(TOTAL_THREADS_FOR_CONCURRENT_READ*REPETITION_FOR_A_THREAD *1000000000) /(double) (aftConTime-befConTime));
		System.out.println("Finished all threads");
		long TOTAL_TIME=0;
		long COUNT_OF_CACHE_HITS =0;
		for(StatisticsPerThread statsPerThread: listOfStatsForThread)
		{
			TOTAL_TIME = statsPerThread.getTotalTimeByOneThread()+TOTAL_TIME;
			COUNT_OF_CACHE_HITS=COUNT_OF_CACHE_HITS+statsPerThread.getTotalNumberOfRunsByThread();
		}
		System.out.println("Average time per operation in nano " + (double)((double)TOTAL_TIME /(double)COUNT_OF_CACHE_HITS));
	//	System.out.println("total time " + (long)(TOTAL_TIME));
	//	System.out.println("count runs " + (long)(COUNT_OF_CACHE_HITS));
		System.out.println("SINGLE ops Per sec time " + (double)((double)COUNT_OF_CACHE_HITS*1000000000/(double)TOTAL_TIME));
		   
		stats.setCurrentTime(System.nanoTime());
		stats.setOpsPerSec(((double)COUNT_OF_CACHE_HITS*1000000000/(double)TOTAL_TIME));
		stats.setAverageTimeforOneGet(((double)TOTAL_TIME/(double)COUNT_OF_CACHE_HITS));
		stats.setConcurrentOperationsPerSec((double)(TOTAL_THREADS_FOR_CONCURRENT_READ*REPETITION_FOR_A_THREAD *1000000000) /(double) (aftConTime-befConTime));
		//System.out.println("READING " +size+  "  cache value"+ orgCache.get(size));
	}





}

