/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.bigmemory.benchmark;

import java.sql.Timestamp;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

/**
 * This example demonstrates use of binary objects with Ignite cache.
 * Specifically it shows that binary objects are simple Java POJOs and do not
 * require any special treatment.
 * <p>
 * The example executes several put-get operations on Ignite cache with binary
 * values. Note that it demonstrates how binary object can be retrieved in
 * fully-deserialized form or in binary object format using special cache
 * projection.
 * <p>
 * Remote nodes should always be started with the following command:
 * {@code 'ignite. sh|bat} examples/config/example-ignite.xml'}
 * <p>
 * Alternatively you can run
 * {@link org.apache.ignite.examples.ExampleNodeStartup} in another JVM which
 * will start a node with {@code examples/config/example-ignite.xml}
 * configuration.
 */
@SuppressWarnings("TypeMayBeWeakened")
public class CacheOBJSimplePutEngine {

	public static void put(Cache cache, int count) {
		// Create new Organization binary object to store in cache.

		for (int x = 0; x < count; x++) {
			// Put created data entry to cache.
			Person p = new Person((long) x, (long) x, "Shariq-" + x, "Mohd" + x);
		 	 Organization org = new Organization(
     	            "Microsoft"+x, // Name.
     	            (long)x,new Address("1096 Eddy Street, San Francisco, CA", 94109), // Address.
     	            OrganizationType.PRIVATE, // Type.
     	            new Timestamp(System.currentTimeMillis())); // Last update time.
 

			cache.put(new Element(p, x));

		}

	}
	
	public static void put(Cache cache, int intialIndex, int cacheSizeIncrement) {
		// Create new Organization binary object to store in cache.

		for (int x = intialIndex; x <=  intialIndex+ cacheSizeIncrement; x++) {
			// Put created data entry to cache.
			Person p = new Person((long) x, (long) x, "Shariq-" + x, "Mohd" + x);
		 	 Organization org = new Organization(
     	            "Microsoft"+x, // Name.
     	            (long)x,new Address("1096 Eddy Street, San Francisco, CA", 94109), // Address.
     	            OrganizationType.PRIVATE, // Type.
     	            new Timestamp(System.currentTimeMillis())); // Last update time.
 

			cache.put(new Element(p, x));

		}

	}


}
