package com.bigmemory.benchmark.util;

public class StatisticsPerRun {
	
	
	private long currentTime;
	private double opsPerSec;
	private double averageTimeforOneGet;
	private double concurrentOperationsPerSec;
	public long getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(long currentTime) {
		this.currentTime = currentTime;
	}
	public double getOpsPerSec() {
		return opsPerSec;
	}
	public void setOpsPerSec(double opsPerSec) {
		this.opsPerSec = opsPerSec;
	}
	public double getAverageTimeforOneGet() {
		return averageTimeforOneGet;
	}
	public void setAverageTimeforOneGet(double averageTimeforOneGet) {
		this.averageTimeforOneGet = averageTimeforOneGet;
	}
	public void setConcurrentOperationsPerSec(double d) {
		// TODO Auto-generated method stub
		this.concurrentOperationsPerSec=d;
		
	}
	public double getConcurrentOperationsPerSec() {
		// TODO Auto-generated method stub
		return concurrentOperationsPerSec;
	}
	
	

}
