/*
 *  Copyright Terracotta, Inc.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.bigmemory.samples.search;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.MemoryUnit;
import net.sf.ehcache.config.SearchAttribute;
import net.sf.ehcache.config.Searchable;
import net.sf.ehcache.config.TerracottaClientConfiguration;
import net.sf.ehcache.config.TerracottaConfiguration;
import net.sf.ehcache.search.Attribute;
import net.sf.ehcache.search.Direction;
import net.sf.ehcache.search.Query;
import net.sf.ehcache.search.Result;
import net.sf.ehcache.search.Results;
import net.sf.ehcache.search.aggregator.Aggregators;
import net.sf.ehcache.search.attribute.AttributeExtractor;
import net.sf.ehcache.search.attribute.AttributeExtractorException;
import net.sf.ehcache.search.query.QueryManager;
import net.sf.ehcache.search.query.QueryManagerBuilder;

import com.bigmemory.commons.model.PersonBM;
import com.bigmemory.commons.model.PersonBM.Gender;

import java.io.IOException;

import static com.bigmemory.commons.util.ReadUtil.waitForInput;

/**
 * <p>Sample app briefly showing some of the api's one can use to search in
 * BigMemory.
 * <p/>
 */
public class BigMemorySearch {

  public static void main(String[] args) throws IOException {


    // Create Cache
    Configuration managerConfig = new Configuration()
        .terracotta(new TerracottaClientConfiguration().url("localhost:9510"))
        .cache(new CacheConfiguration().name("bigMemorySample")
            .eternal(true)
            .maxBytesLocalHeap(128, MemoryUnit.MEGABYTES)
            .terracotta(new TerracottaConfiguration().consistency(TerracottaConfiguration.Consistency.STRONG))
            .searchable(new Searchable()
                .searchAttribute(new SearchAttribute().name("age"))
                .searchAttribute(new SearchAttribute().name("gender").expression("value.getGender()"))
                .searchAttribute(new SearchAttribute().name("state").expression("value.getAddress().getState()"))
                .searchAttribute(new SearchAttribute().name("name").className(NameAttributeExtractor.class.getName()))
            )
        );

    CacheManager manager = CacheManager.create(managerConfig);
    Ehcache bigMemory = manager.getEhcache("bigMemorySample");

    try {
      loadCache(bigMemory);


      Attribute<String> name = bigMemory.getSearchAttribute("name");
      Attribute<Integer> age = bigMemory.getSearchAttribute("age");
      Attribute<Gender> gender = bigMemory.getSearchAttribute("gender");
      Attribute<String> state = bigMemory.getSearchAttribute("state");

      Query query = bigMemory.createQuery();
      query.includeKeys();
      query.includeValues();
      query.addCriteria(age.eq(23).and(gender.eq(Gender.FEMALE)))
          .addOrderBy(age, Direction.ASCENDING).maxResults(10);

      System.out
          .println("**** Searching for persons whose age is 23 and is female: ****");

      Results results = query.execute();
      System.out.println(" Size: " + results.size());
      System.out.println("----Results-----\n");
      for (Result result : results.all()) {
        System.out.println("Got: Key[" + result.getKey()
                           + "] Value class [" + result.getValue().getClass()
                           + "] Value [" + result.getValue() + "]");
      }

      waitForInput();

      System.out.println("**** Adding another female Julie aged 23 ****");

      bigMemory.put(new Element(1, new PersonBM("Julie Smith", 23, Gender.FEMALE,
          "eck street", "San Mateo", "CA")));

      System.out
          .println("**** Again Searching for persons whose age is 23 and is female: ****");
      results = query.execute();
      System.out.println(" Size: " + results.size());

      waitForInput();

      System.out
          .println("**** Find the average age of all the entries ****");

      Query averageAgeQuery = bigMemory.createQuery();
      averageAgeQuery.includeAggregator(Aggregators.average(age));
      System.out.println("Average age: "
                         + averageAgeQuery.execute().all().iterator().next()
          .getAggregatorResults());

      waitForInput();

      System.out
          .println("**** Find the average age of all people between 30 and 40 ****");
      Query agesBetween = bigMemory.createQuery();
      agesBetween.addCriteria(age.between(30, 40));
      agesBetween.includeAggregator(Aggregators.average(age));
      System.out.println("Average age between 30 and 40: "
                         + agesBetween.execute().all().iterator().next()
          .getAggregatorResults());

      waitForInput();

      System.out.println("**** Find the count of people from NJ ****");

      Query newJerseyCountQuery = bigMemory.createQuery().addCriteria(
          state.eq("NJ"));
      newJerseyCountQuery.includeAggregator(Aggregators.count());
      System.out.println("Count of people from NJ: "
                         + newJerseyCountQuery.execute().all().iterator().next()
          .getAggregatorResults());


      waitForInput();

      System.out.println("****** Now running search queries by " +
                         "executing Big Memory Structured Query Language (BMSQL) statements. ****");

      // For using BMSQl, the first step is to instantiate the QueryManager
      QueryManager queryManager = QueryManagerBuilder.
          newQueryManagerBuilder().addAllCachesCurrentlyIn(manager).build();

      waitForInput();

      System.out
          .println("**** Searching for persons whose name starts with 'M': ****");

      String ilike = "select name from bigMemorySample where (name ilike 'M*')";
      System.out
          .println("BMSQL statement: " + ilike);
      Query ilikeQuery =  queryManager.createQuery(ilike);
      results = ilikeQuery.end().execute();

      System.out.println("Query executed, obtained " + results.size() + " results. Showing results:");
      for (Result result : results.all()) {
        System.out.println("Name = " + result.getAttribute(name));
      }

      waitForInput();

      System.out
          .println("**** Searching for persons who are 23 years old: ****");

      String ageString = "select name, age from bigMemorySample where (age = 23)";
      System.out
          .println("BMSQL statement: " + ageString);
      Query ageQuery =  queryManager.createQuery(ageString);
      results = ageQuery.end().execute();

      System.out.println("Query executed, obtained " + results.size() + " results. Showing results:");
      for (Result result : results.all()) {
        System.out.println("Name = " + result.getAttribute(name) + " , age = " + result.getAttribute(age));
      }

      waitForInput();

      System.out
          .println("**** Searching for persons who are 23 years old and whose name starts with 'M': ****");

      String ageString2 = "select name, age from bigMemorySample where ((age = 23) and (name ilike 'M*'))";
      System.out
          .println("BMSQL statement: " + ageString2);
      Query ageQuery2 =  queryManager.createQuery(ageString2);
      results = ageQuery2.end().execute();

      System.out.println("Query executed, obtained " + results.size() + " results. Showing results:");
      for (Result result : results.all()) {
        System.out.println("Name = " + result.getAttribute(name) + " , age = " + result.getAttribute(age));
      }

      System.out.println("**** End of example, exiting.... ");

    } finally {
      if (manager != null) manager.shutdown();
    }
  }

  private static void loadCache(Ehcache bigMemory) {
    bigMemory.put(new Element(1, new PersonBM("Jane Doe", 35, Gender.FEMALE,
        "eck street", "San Mateo", "CA")));
    bigMemory.put(new Element(2, new PersonBM("Marie Antoinette", 23, Gender.FEMALE,
        "berry st", "Parsippany", "LA")));
    bigMemory.put(new Element(3, new PersonBM("John Smith", 23, Gender.MALE,
        "big wig", "Beverly Hills", "NJ")));
    bigMemory.put(new Element(4, new PersonBM("Paul Dupont", 45, Gender.MALE,
        "cool agent", "Madison", "WI")));
    bigMemory.put(new Element(5, new PersonBM("Juliet Capulet", 30, Gender.FEMALE,
        "dah man", "Bangladesh", "MN")));
    bigMemory.put(new Element(6, new PersonBM("Mary Claire", 30, Gender.FEMALE,
        "dah woman", "Boston", "MA")));
    for (int i = 7; i < 1000; i++) {
      bigMemory.put(new Element(i, new PersonBM("Juliet Capulet" + i, 30,
          PersonBM.Gender.MALE, "dah man", "Bangladesh", "NJ")));
    }
  }


  public static class NameAttributeExtractor implements AttributeExtractor {

    /**
     * Implementing the AttributeExtractor Interface and passing it in
     * allows you to create very efficient and specific attribute extraction
     * for performance sensitive code
     */

    public Object attributeFor(Element element) {
      return ((PersonBM)element.getObjectValue()).getName();
    }

    public Object attributeFor(Element element, String arg1)
        throws AttributeExtractorException {
      return attributeFor(element);
    }
  }
}
