//
// Created by Alex Snaps on 10/29/13.
// Copyright (c) 2013 Terracotta. All rights reserved.
//



#ifndef __RecipeProtoBufSerializer_H_
#define __RecipeProtoBufSerializer_H_

#include <bigmemory/serialization/cache_serializer.h>
#include "recipe.pb.h" // this is the generated header file, from protoc

static char const *const KEY_NAME = "ID";

using RecipeProject::RecipeStructure;
using terracotta::ehcache::serialization::CacheSerializer;
using terracotta::ehcache::serialization::CacheValue;
using terracotta::ehcache::utilities::ValueObject;

class RecipeProtoBufSerializer : public CacheSerializer<std::string, RecipeStructure> {
public:

    RecipeProtoBufSerializer() {
    }

    virtual ValueObject serializeKey(std::string &deserializedKey);

    virtual std::string deserializeKey(ValueObject &serializedKey);

    virtual CacheValue serializeValue(RecipeStructure &deserializedValue);

    virtual RecipeStructure deserializeValue(CacheValue &serializedValue);

};


#endif //__RecipeProtoBufSerializer_H_
