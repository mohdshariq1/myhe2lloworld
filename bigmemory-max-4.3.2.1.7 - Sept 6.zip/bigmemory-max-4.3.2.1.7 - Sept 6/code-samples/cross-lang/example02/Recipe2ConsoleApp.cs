﻿using System;
using System.Collections.Generic;
using Terracotta.Ehcache;
using Terracotta.Ehcache.Caching;
using Terracotta.Ehcache.Search;

namespace Demo.Recipe2
{
    class Recipe2Repository
    {
        Dictionary<string, Recipe2> repo = new Dictionary<string, Recipe2>();

        public Recipe2Repository()
        {
            Recipe2 recipe = new Recipe2Builder("Mac&Cheese")
                .description("All-American fave!")
                .preptime(15)
                .ingredient(2.0f, "cups", "noodles")
                .ingredient(8.0f, "ounces", "cheddar")
                .methodStep("combine")
                .methodStep("bake")
                .baketime(45)
                .servingInstruction(4, "cups")
                .build();
            repo[recipe.Name] = recipe;

            recipe = new Recipe2Builder("BreadedChicken")
                .description("mom's Breaded Chicken")
                .preptime(15)
                .ingredient(4.0f, "breasts", "chicken")
                .ingredient(8.0f, "ounces", "mayo")
                .ingredient(2.0f, "cups", "breadcrumbs")
                .ingredient(2.0f, "teaspoon", "salt")
                .ingredient(1.0f, "teaspoon", "pepper")
                .ingredient(1.0f, "teaspoon", "paprika")
                .methodStep("combine mayo and spices in bowl")
                .methodStep("cover each chicken breast in mayo mixture")
                .methodStep("roll chicken in bread crumbs")
                .methodStep("place on baking sheet")
                .methodStep("bake at 375 degrees")
                .baketime(45)
                .build();
            repo[recipe.Name] = recipe;
        }

        public Recipe2 Recipe(string name)
        {
            return repo[name];
        }
    }

    class Recipe2ConsoleApp
    {
        static void Main(string[] args)
        {

            Recipe2Repository repo = new Recipe2Repository();

            ICacheManager cacheManager = XPlatform.CreateCacheManager(new Terracotta.Ehcache.Config.Configuration("127.0.0.1", 8199, 100));

            ICache<string, Recipe2> cache = cacheManager.GetCache("TestCache", new Recipe2BsonSerializer());
            if (args[0].ToLower().Equals("put"))
            {
                Recipe2 rec = repo.Recipe(args[1]);
                cache.Put(rec.Name, rec, ConsistencyType.STRONG);
                Console.WriteLine("Put of " + rec.Name + " complete");
            }
            else if (args[0].ToLower().Equals("get"))
            {
                Recipe2 rec = (Recipe2)cache.Get(args[1], ConsistencyType.STRONG);

                if (rec == null)
                {
                    Console.WriteLine("Key: " + args[1] + " not found");
                }
                else
                {
                    Console.WriteLine(rec.ToString());
                }
            }
            else if (args[0].ToLower().Equals("query"))
            {
                Console.WriteLine("Querying: " + args[1]);
                SearchResults<string, Recipe2> results = cache.Query(args[1]);
                Console.WriteLine(results.Results.Count);
                foreach (SearchResult<string, Recipe2> r in results.Results)
                {
                    Console.WriteLine(r.Key + " :: " + r.Value);
                }
            }
            else if (args[0].ToLower().Equals("clear"))
            {
                cache.RemoveAll();
                Console.WriteLine("Cache cleared");
            }

            cacheManager.Close();
        }
    }
}
