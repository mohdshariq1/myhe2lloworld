﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Bson;
using Terracotta.Ehcache.Serialization;
using Terracotta.Ehcache.Thrift;
using Terracotta.Ehcache.Utilities;

namespace Demo.Recipe2
{
    public class Recipe2BsonSerializer : ICacheSerializer<string, Recipe2>
    {
        public Terracotta.Ehcache.Thrift.Value SerializeKey(string key)
        {
            return ValueHelper.NewValue(key);
        }

        public string DeserializeKey(Terracotta.Ehcache.Thrift.Value serializedKey)
        {
            return (string)ValueHelper.FindSetValue(serializedKey);
        }

        public StoredValue SerializeValue(Recipe2 objectValue)
        {
            MemoryStream ms = new MemoryStream();
            // serialize recipe to BSON       
            BsonWriter writer = new BsonWriter(ms); 
            
            JsonSerializer serializer = new JsonSerializer();
            serializer.Serialize(writer, objectValue);
            byte[] barray = ms.ToArray();

            Dictionary<String, Object> nvPairs = new Dictionary<String, Object>();
            // two indexable attributes
            nvPairs["name"] = objectValue.Name;
            nvPairs["bakingTime"] = objectValue.BakingTime;
            // ship the bson version of the recipe as a byte array
            return ValueHelper.NullSafeStoredValue(barray, nvPairs);
        }

        public Recipe2 DeserializeValue(Terracotta.Ehcache.Thrift.StoredValue value)
        {
            MemoryStream ms = new MemoryStream(value.Value.BinaryValue);
            ms.Seek(0, SeekOrigin.Begin);            
            BsonReader reader = new BsonReader(ms);            
            JsonSerializer serializer = new JsonSerializer();
            Recipe2 recipe = serializer.Deserialize<Recipe2>(reader);
            return recipe;
        }

    }
}
