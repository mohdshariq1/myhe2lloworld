README for the Server Wrapper 
======================== 

The Sever Wrapper allows you to start the Terracotta Server Array or the Cross-Language Connector as a service. Follow the instructions below to get started. 


1. SET JAVA_HOME 
------------------------------- 
To start the services, set your JAVA_HOME in conf/wrapper-tsa.conf or conf/wrapper-clc.conf. For example: 

set.JAVA_HOME=C:/Java/jdk1.7.0_21 

NOTE: The wrapper does not read your JAVA_HOME from the environment. For Windows, if you do not want to set it in the configuration file, comment it out and set JAVA_HOME in the registry instead. 


2. CONFIGURATION FILES 
----------------------------------------- 
A. For the Cross-Language Connector, you will need 2 configuration files: 

conf/cross-language-config.xml 
conf/ehcache.xml 


B. For TSA, you will need 1 configuration file: 

conf/tc-config.xml 

Please overwrite those files with your own. If you want to change these file names, you can modify the 
names in wrapper configurations. 


C. The TSA conf/wrapper-tsa.conf will need to know which server you want to start. So modify the following line to the one in your tc-config.xml: 

set.SERVER_NAME=server0 


3. PERMISSION 
------------------------- 
The services will be controlled by an Administrator user, so you have to confirm for every action 
(install, start, stop, remove, etc). 

In addition, the "wrapper" directory will need to have read/write permission for the Administrator user. 


4. RUNNING SERVICES 
------------------------------------ 
The service needs to be installed once before it can be started. To install, run the script with the install parameter: 

%> bin/tsa-service.bat install 

NOTE: The examples in this section show the TSA script. For the Cross-Language Connector, use the clc-service or clc-service.bat script. 

Then you can either start/stop the service: 

%> bin/tsa-service.bat start 
%> bin/tsa-service.bat stop 

If you want to remove the service: 

%> bin/tsa-service.bat remove 

There are more commands available when you run the script without any parameter: 

%> bin/tsa-service.bat 


5. CHANGING WRAPPER CONFIGURATIONS 
-------------------------------------------------------------------- 
There are comments in wrapper-tsa.conf and wrapper-clc.conf to explain each parameter. 
If you need to modify JVM system properties, classpath, command line parameters, etc., 
follow the current pattern. Please pay close attention to their numerical 
order and parameter counts. 

For more information, see: 
http://wrapper.tanukisoftware.com/doc/english/properties.html 

