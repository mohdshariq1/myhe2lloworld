/*
 *  Copyright Terracotta, Inc.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.bigmemory.samples.crud;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;
import net.sf.ehcache.config.MemoryUnit;
import net.sf.ehcache.config.TerracottaClientConfiguration;
import net.sf.ehcache.config.TerracottaConfiguration;

import com.bigmemory.commons.model.Person;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import static com.bigmemory.commons.util.ReadUtil.waitForInput;

/**
 * <p>Sample app briefly showing some of the api's one can use to create, read, update and delete in
 * BigMemory.
 * <p/>
 */
public class BigMemoryCrud2 {

  public static void main(String[] args) throws IOException {
    /** Setting up the bigMemory configuration **/
	  System.out.println("JULY 28***********************************************************");
    Configuration managerConfiguration = new Configuration();
    managerConfiguration.name("config")
        .terracotta(new TerracottaClientConfiguration().url("localhost:9510"))
        .cache(new CacheConfiguration()
            .name("bigMemory-crud")
            .maxBytesLocalHeap(128, MemoryUnit.MEGABYTES)
            .terracotta(new TerracottaConfiguration())
        );

    CacheManager manager = CacheManager.create(managerConfiguration);
    Cache bigMemory = manager.getCache("bigMemory-crud");

    try {
   
    	System.out.println("Number of element : " + bigMemory.getSize());
      Person timDoe2 ;
      int n=1000;
      do{
    	  for(int x1=n;x1<n+1000;x1++){
    		  int x=x1;//ThreadLocalRandom.current().nextInt(n);
        	  timDoe2 = new Person("Shariq-"+x, x, Person.Gender.MALE,
        		          "eck street", "San Mateo", "CA");
        		      bigMemory.put(new Element("1"+x, timDoe2));

        	    	
        		      System.out.println("Writing = "+ x);  
    	  }
    	  

    	  for(int x2=n;x2<n+1000;x2++){
    		  int y=x2;//ThreadLocalRandom.current().nextInt(n);
	    	  Element p =   bigMemory.get("1"+y);
  		    	  
		      System.out.println("Reading = "+y+ "Element "+ p.getObjectValue());
                		  
    	  }
    	  

      
      n=n+1000;
      
      }while (true);
    
    
    } finally {
      if (manager != null) manager.shutdown();
    }
  }


}
