/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.ignite.all.greatwest.object;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.all.greatwest.graph.JfreeChart;
import org.apache.ignite.all.greatwest.util.AllNodesStartup;
import org.apache.ignite.all.greatwest.util.LineChart;
import org.apache.ignite.all.greatwest.util.StatisticsPerRun;
import org.apache.ignite.all.greatwest.util.StatisticsPerSet;
import org.apache.ignite.all.greatwest.util.StatisticsPerThread;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.all.greatwest.object.Organization;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 * This example demonstrates use of binary objects with cache queries.
 * The example populates cache with sample data and runs several SQL and full text queries over this data.
 * <p>
 * Remote nodes should always be started with the following command:
 * {@code 'ignite.{sh|bat} examples/config/example-ignite.xml'}
 * <p>
 * Alternatively you can run {@link org.apache.ignite.examples.ExampleNodeStartup} in another JVM which will
 * start a node with {@code examples/config/example-ignite.xml} configuration.
 */
public class CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE {
    public static final int REPETITION_FOR_A_THREAD = 200;

	private static final int CACHE_INCREMENT = 5000;

	private static final int MAX_CACHE_SIZE = 20000;

	public static final long NUMBER_OF_RUNS_TEST = 10;

	public static final String CACHE_NAME = "CacheOBJSimplePutEngine";

	public static final long TOTAL_THREADS_FOR_CONCURRENT_READ = 30;

	public static  long THREAD_POOLSIZE_FOR_CONCURRENT_READ = 15;

	/** Organization cache name. */
    private static final String ORGANIZATION_CACHE_NAME = CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE.class.getSimpleName()
        + "Organizations";

    /** Employee cache name. */
    private static final String EMPLOYEE_CACHE_NAME = CacheOBJConcurrentGetEngineMultipeRunsWithCACHESIZE.class.getSimpleName()
        + "Employees";

    /**
     * Executes example.
     *
     * @param args Command line arguments, none required.
     * @throws InterruptedException 
     * @throws IOException 
     */
    public static void main(String[] args) throws InterruptedException, IOException {
        AllNodesStartup.start(1);
        
    	try (Ignite ignite = Ignition.start("examples/config/example-ignite.xml")) {
            System.out.println();
            System.out.println(">>> Binary objects cache query example started.");

            CacheConfiguration<Person, Organization> orgCacheCfg = new CacheConfiguration<>();

            orgCacheCfg.setCacheMode(CacheMode.REPLICATED);
            orgCacheCfg.setName(CACHE_NAME);//"CacheClientBinaryPutGetExample");//(ORGANIZATION_CACHE_NAME);

      

            try (IgniteCache<Person, Organization> orgCache = ignite.getOrCreateCache(orgCacheCfg);
                 
            ) {
                if (ignite.cluster().forDataNodes(orgCache.getName()).nodes().isEmpty()) {
                    System.out.println();
                    System.out.println(">>> This example requires remote cache nodes to be started.");
                    System.out.println(">>> Please start at least 1 remote cache node.");
                    System.out.println(">>> Refer to example's javadoc for details on configuration.");
                    System.out.println();

                    return;
                }
                

        		DefaultCategoryDataset finalStats = new DefaultCategoryDataset();
        		        
                for(int i=0;i<=MAX_CACHE_SIZE;i=i+CACHE_INCREMENT){
                System.out.println("OuterMOST LOOP - Varying Parameter CacheSize index=" + i);
              //  	THREAD_POOLSIZE_FOR_CONCURRENT_READ=i;
                	CacheOBJSimplePutEngine.putGet(orgCache, i, i+CACHE_INCREMENT);
                	StatisticsPerSet statSet=new StatisticsPerSet();
                	executePerSetOfThreads(ignite, orgCache, statSet,i,i+CACHE_INCREMENT);
                	
                	finalStats.setValue(statSet.getOpsPerSec(),
    						"  Concurrent Ops Per Sec ",
    						(Long) (long)(i+CACHE_INCREMENT ));
                	System.out.println(statSet.getOpsPerSec()+
    						"OuterMOST LOOP TOTAL Concurrent Ops Per Sec "+
    						(Long) (long)(i+CACHE_INCREMENT ));
    					
                }
                
			JfreeChart.graph(finalStats, " Graph :: Operations per Sec per CacheSize ", "Number of Operations Per Second", "CacheSize", "Number of Operations Per Second...");
          // LineChart.graph(finalStats, "Graph :: Operations per Sec per CacheSize", "  OneGetPutGetTX OpsPerSec ", "Number of Operations Per Second", "CacheSize");

               
            }
        }
    }

	private static void executePerSetOfThreads(Ignite ignite,
			IgniteCache<Person, Organization> orgCache, StatisticsPerSet stasSet, int startCacheIndex, int endCacheIndex)
			throws InterruptedException {
		List<StatisticsPerRun> statsList = new ArrayList<StatisticsPerRun>();	
            long befTime=System.nanoTime();
	
    	     
       for(int i=0;i<NUMBER_OF_RUNS_TEST;i++){
		    System.out.println("Second OuterMOST LOOP RUN index=" + i);
		     
			StatisticsPerRun stats = new StatisticsPerRun();
			executeGetCache(orgCache, ignite, stats, startCacheIndex,endCacheIndex);
			statsList.add(stats);
	 }
		
	
		long aftTime=System.nanoTime();
        
		//stasSet.setOpsPerSec((double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime));
		
		
		DefaultCategoryDataset dataSetOpsPerSec = new DefaultCategoryDataset();
		DefaultCategoryDataset dataSetAvgTimeForOneOp = new DefaultCategoryDataset();
		DefaultCategoryDataset dataSetConcurrentOpsPerSec = new DefaultCategoryDataset();
		int i=0;long baseTime=0;

    	double AVG_TIME_SET=0;
		double OPS_PER_SEC_SET =0;
		for(StatisticsPerRun statPerRun : statsList){ 

			AVG_TIME_SET = (long) (statPerRun.getAverageTimeforOneGet()+AVG_TIME_SET);
			OPS_PER_SEC_SET=OPS_PER_SEC_SET+ statPerRun.getConcurrentOperationsPerSec();
			System.out.println("OPS_PER_SEC_SET ="+ OPS_PER_SEC_SET);
			
//			if (i > 1) {// since couple of test take time to warmup
				if (i == 0) {
					baseTime = (Long) statPerRun.getCurrentTime();
				}

				 System.out.println("SEcond OUTER - PER RUN OpsPerSec=" +statPerRun.getOpsPerSec() +" --time interval="
				 + (Long)(statPerRun.getCurrentTime() - baseTime) + " concurrent ops per sec  "+ statPerRun.getConcurrentOperationsPerSec());
				dataSetOpsPerSec.setValue(statPerRun.getOpsPerSec(),
						" Ops Per Sec ",
						(Long) (statPerRun.getCurrentTime() - baseTime));
				
				dataSetConcurrentOpsPerSec.setValue(statPerRun.getConcurrentOperationsPerSec(),
						" Concurrent Ops Per Sec ",
						(Long) (statPerRun.getCurrentTime() - baseTime));
				dataSetAvgTimeForOneOp.setValue(statPerRun.getAverageTimeforOneGet(),
						" Avg Time ",
						(Long) (statPerRun.getCurrentTime() - baseTime));
	//		}
			i++;
		}
		System.out.println("OuterMOST Total Time for One SET-(aftTime-befTime)= " +(aftTime-befTime));
		System.out.println("OuterMOST OLDER   Total Ops One SET Per Sec " + (double)((long)NUMBER_OF_RUNS_TEST*(long)TOTAL_THREADS_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime));
			stasSet.setCurrentTime(System.currentTimeMillis());
			stasSet.setOpsPerSec(OPS_PER_SEC_SET/NUMBER_OF_RUNS_TEST);
			stasSet.setAverageTimeforOneGet(AVG_TIME_SET/NUMBER_OF_RUNS_TEST);
			System.out.println("OUTER LOOP -->OPS/SEC=" + stasSet.getOpsPerSec() +" AVERGE  "+ stasSet.getAverageTimeforOneGet());
			System.out.println("OUTER LOOP -->OPS_PER_SEC_SET " + OPS_PER_SEC_SET + "NUMBER_OF_RUNS_TEST "+NUMBER_OF_RUNS_TEST +" AVG_TIME_SET "+ AVG_TIME_SET);
			
    /*        JfreeChart.graph(dataSetOpsPerSec, "  OneGetPutGetTX OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Operations Per Second", "Test Run Index", "Operations per second");
            JfreeChart.graph(dataSetConcurrentOpsPerSec, "  OneGetPutGetTX - ALL OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Concurrent Operations Per Second", "Test Run Index", "Concurrent Operations per second");
            JfreeChart.graph(dataSetAvgTimeForOneOp, "  OneGetPutGetTX AverageTime " +   (int)((double)(aftTime-befTime)/(int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD )) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf", "Average Time in Nanoseconds", "Test Run Index", "Average Time taken by One Operation");


            
            LineChart.graph(dataSetOpsPerSec, "Operations per second", "  OneGetPutGetTX OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Operations Per Second", "Test Run Index");
            LineChart.graph(dataSetConcurrentOpsPerSec,"Concurrent Operations per second", "  OneGetPutGetTX - ALL OpsPerSec " + (int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD *(long)1000000000) / (double)(aftTime-befTime) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf","Number of Concurrent Operations Per Second", "Test Run Index" );
            LineChart.graph(dataSetAvgTimeForOneOp,"Average Time For One Operation", "  OneGetPutGetTX AverageTime " +   (int)((double)(aftTime-befTime)/(int)((double)((long)NUMBER_OF_RUNS_TEST*(long)THREAD_POOLSIZE_FOR_CONCURRENT_READ*(long)REPETITION_FOR_A_THREAD )) ) +"  Threads- "+THREAD_POOLSIZE_FOR_CONCURRENT_READ + " ---Runs-"+NUMBER_OF_RUNS_TEST +"  -nodes-4.pdf", "Average Time in Nanoseconds", "Test Run Index");
*/	}

	private static void executeGetCache(
			IgniteCache<Person, Organization> orgCache,Ignite ignite, StatisticsPerRun stats, int startCacheIndex, int endCacheIndex)
			throws InterruptedException {
		List<StatisticsPerThread> listOfStatsForThread = new ArrayList<StatisticsPerThread>(50000);
		
		ExecutorService executor = Executors.newFixedThreadPool((int)THREAD_POOLSIZE_FOR_CONCURRENT_READ);
            //	List<Statistics> listOfStats = new ArrayList<Statistics>(50000);
		long befConTime=System.nanoTime();
		for (int i = 0; i < TOTAL_THREADS_FOR_CONCURRENT_READ; i++) {
				listOfStatsForThread.add(i, new StatisticsPerThread());
		        Runnable worker = new CacheOBJGetRunnableWithCacheSizeVariant(orgCache, ignite , listOfStatsForThread.get(i), startCacheIndex, endCacheIndex);
		        executor.execute(worker);
		        //TheUtils.timeLapse(2);
		}
		// This will make the executor accept no new threads
		// and finish all existing threads in the queue
		executor.shutdown();
		// Wait until all threads are finish
		executor.awaitTermination(1,TimeUnit.HOURS);
		long aftConTime=System.nanoTime();
		System.out.println("Second OuterMOST -RUN-TOT time=(aftConTime-befConTime)  "+ (aftConTime-befConTime) + "  EndCacheIdex = " + endCacheIndex);
		System.out.println("Second OuterMOST -RUN-TOT ops per sec="+ (double)(TOTAL_THREADS_FOR_CONCURRENT_READ*REPETITION_FOR_A_THREAD *1000000000) /(double) (aftConTime-befConTime));
		System.out.println("Second OuterMOST -RUN-Finished all threads");
		long TOTAL_TIME=0;
		long COUNT_OF_CACHE_HITS =0;
		for(StatisticsPerThread statsPerThread: listOfStatsForThread)
		{
			TOTAL_TIME = statsPerThread.getTotalTimeByOneThread()+TOTAL_TIME;
			COUNT_OF_CACHE_HITS=COUNT_OF_CACHE_HITS+statsPerThread.getTotalNumberOfRunsByThread();
		}
		System.out.println("Second OuterMOST -RUN- SINGLE THREAD  Average time per operation in nano " + (double)((double)TOTAL_TIME /(double)COUNT_OF_CACHE_HITS));
	//	System.out.println("total time " + (long)(TOTAL_TIME));
	//	System.out.println("count runs " + (long)(COUNT_OF_CACHE_HITS));
		System.out.println("Second OuterMOST -RUN- SINGLE THREAD ops Per sec time " + (double)((double)COUNT_OF_CACHE_HITS*1000000000/(double)TOTAL_TIME));
		   
		stats.setCurrentTime(System.nanoTime());
		stats.setOpsPerSec(((double)COUNT_OF_CACHE_HITS*1000000000/(double)TOTAL_TIME));
		stats.setOpsPerSec(((double)COUNT_OF_CACHE_HITS*1000000000/(double)TOTAL_TIME));
		stats.setAverageTimeforOneGet(((double)TOTAL_TIME/(double)COUNT_OF_CACHE_HITS));
		stats.setConcurrentOperationsPerSec((double)(TOTAL_THREADS_FOR_CONCURRENT_READ*REPETITION_FOR_A_THREAD *1000000000) /(double) (aftConTime-befConTime));
		//System.out.println("READING " +size+  "  cache value"+ orgCache.get(size));
	}





}

