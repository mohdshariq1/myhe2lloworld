package org.apache.ignite.all.greatwest.util;

public class StatisticsPerThread {
	
	public long getTotalNumberOfRunsByThread() {
		return totalNumberOfRunsByThread;
	}
	public void setTotalNumberOfRunsByThread(long totalNumberOfRunsByThread) {
		this.totalNumberOfRunsByThread = totalNumberOfRunsByThread;
	}
	public long getTotalTimeByOneThread() {
		return totalTimeByOneThread;
	}
	public void setTotalTimeByOneThread(long totalTimeByOneThread) {
		this.totalTimeByOneThread = totalTimeByOneThread;
	}
	long totalNumberOfRunsByThread=0;
	long totalTimeByOneThread;
	
	
}
