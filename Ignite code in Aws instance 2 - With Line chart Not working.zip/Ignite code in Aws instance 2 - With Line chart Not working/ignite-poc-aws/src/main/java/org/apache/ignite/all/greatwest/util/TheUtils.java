package org.apache.ignite.all.greatwest.util;

public class TheUtils {
	
	  public static final long NUMBER_OF_RUNS_TEST = 30;

		public static final String CACHE_NAME = "CacheSimplePutEngine";

		public static final long TOTAL_THREADS_FOR_CONCURRENT_READ = 80;

		public static final long THREAD_POOLSIZE_FOR_CONCURRENT_READ = 40;

	public static void timeLapse(int interval){
		try {
			Thread.sleep(1*interval);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		long befConTime=Long.valueOf("1000000000");
				long aftConTime=Long.valueOf("6345377284");
		System.out.println((Long.valueOf("16000000000000")) /(double) (Long.valueOf("5345377284")));
		System.out.println("TOT ops per sec="+ (double)(THREAD_POOLSIZE_FOR_CONCURRENT_READ*2*200 *1000000000) /(double) (aftConTime-befConTime));
		
	}
	

}
