package org.apache.ignite.all.greatwest.util;

import java.io.File;
import java.io.IOException;

import org.apache.ignite.examples.ExampleNodeStartup;

public final class JavaProcess {

    private JavaProcess() {}        

    public static int exec(Class klass) throws IOException,
                                               InterruptedException {
        String javaHome = System.getProperty("java.home");
        String javaBin = javaHome +
                File.separator + "bin" +
                File.separator + "java";
        String classpath = System.getProperty("java.class.path");
        String className = klass.getCanonicalName();

        ProcessBuilder builder = new ProcessBuilder(
                javaBin, "-cp", classpath, className);
        builder.inheritIO();
        Process process = builder.start();
       /* process.waitFor();
        return process.exitValue();*/
        return 0;
    }
    
    public static int execNodeStartup() throws IOException,
    InterruptedException {
		String javaHome = System.getProperty("java.home");
		String javaBin = javaHome +
		File.separator + "bin" +
		File.separator + "java";
		String classpath = System.getProperty("java.class.path");
		String className = ExampleNodeStartup.class.getCanonicalName();
		
		ProcessBuilder builder = new ProcessBuilder(
		javaBin, "-cp", classpath, className);
		builder.inheritIO();
		Process process = builder.start();
		/* process.waitFor();
		return process.exitValue();*/
		return 0;
}
}