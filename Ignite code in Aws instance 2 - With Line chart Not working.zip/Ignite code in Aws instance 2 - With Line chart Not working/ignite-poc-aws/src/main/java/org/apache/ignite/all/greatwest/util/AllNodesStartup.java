package org.apache.ignite.all.greatwest.util;

import java.io.IOException;

import org.apache.ignite.all.greatwest.util.JavaProcess;
import org.apache.ignite.all.greatwest.util.TheUtils;

public class AllNodesStartup {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		int numOfNodes = Integer.parseInt(args[0]);
		
		for(int i=0;i<=numOfNodes;i++){
			JavaProcess.execNodeStartup();
			TheUtils.timeLapse(5);
		}
	
		System.out.println("Nodes started");
	
	
		System.out.println("End");
		
	}
	
	public static void start(int numOfNodes) throws IOException, InterruptedException {
		for(int i=0;i<numOfNodes;i++){
			JavaProcess.execNodeStartup();
			TheUtils.timeLapse(5);
		}
	
		System.out.println("Nodes started");
	
	
		System.out.println("End");
		
	}

}
