package com.test.instrument;

public class D {
    private int x;
    private int y;

    public static void main(String [] args) {
        System.out.println("Hi");
    }
}